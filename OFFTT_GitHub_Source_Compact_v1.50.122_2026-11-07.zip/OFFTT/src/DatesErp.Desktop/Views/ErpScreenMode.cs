namespace DatesErp.Desktop.Views;

/// <summary>الحالة التشغيلية الموحدة للشاشة؛ لا تحل محل قواعد عمل المستند نفسه.</summary>
public enum ErpScreenMode
{
    View,
    Add,
    Edit,
    Search,
    Saving
}
